execute if score @s nm_cooldown matches ..0 if entity @p[tag=nightmare_chased,distance=25..90] run function nightmare:mimic_appear
execute if entity @p[tag=nightmare_chased,distance=..45] run playsound minecraft:block.scaffolding.step master @p[tag=nightmare_chased,sort=nearest,limit=1] ~ ~ ~ 0.35 0.5
