scoreboard players set @s nm_cooldown 180
execute as @p[tag=nightmare_chased,sort=nearest,limit=1] at @s positioned ^ ^ ^-6 run tp @e[tag=hollow_mimic,sort=nearest,limit=1] ~ ~ ~
execute as @p[tag=nightmare_chased,sort=nearest,limit=1] at @s run title @s actionbar {"text":"behind you","color":"white","bold":false}
execute as @p[tag=nightmare_chased,sort=nearest,limit=1] at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.7 0.45
execute as @p[tag=nightmare_chased,sort=nearest,limit=1] at @s run particle minecraft:ash ~ ~1 ~ 1.2 1.2 1.2 0.03 60 force
