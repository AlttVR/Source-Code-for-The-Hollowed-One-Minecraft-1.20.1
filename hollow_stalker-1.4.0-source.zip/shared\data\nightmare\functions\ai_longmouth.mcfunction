execute if entity @p[tag=nightmare_chased,distance=..80] run attribute @s minecraft:generic.movement_speed base set 0.58
execute if entity @p[tag=nightmare_chased,distance=..40] run function nightmare:break_blocks
execute if entity @p[tag=nightmare_chased,distance=..25] run playsound minecraft:entity.warden.roar master @p[tag=nightmare_chased,sort=nearest,limit=1] ~ ~ ~ 0.5 0.65
execute if entity @p[tag=nightmare_chased,distance=..2.4] run function nightmare:caught_player
