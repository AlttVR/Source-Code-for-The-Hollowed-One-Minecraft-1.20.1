scoreboard players set #event nm_timer 0
scoreboard players add #event_stage nm_timer 1
execute if score #event_stage nm_timer matches 5.. run scoreboard players set #event_stage nm_timer 1

execute if score #event_stage nm_timer matches 1 run scoreboard players set #event_gap nm_timer 3600
execute if score #event_stage nm_timer matches 2 run scoreboard players set #event_gap nm_timer 4800
execute if score #event_stage nm_timer matches 3 run scoreboard players set #event_gap nm_timer 6000
execute if score #event_stage nm_timer matches 4 run scoreboard players set #event_gap nm_timer 2400

execute as @e[tag=nightmare_stalker,limit=1] at @s run title @a[tag=nightmare_chased,distance=..80] actionbar {"text":"IT SAW YOU","color":"white","bold":false}
execute as @e[tag=nightmare_stalker,limit=1] at @s run playsound minecraft:entity.warden.listening master @a[tag=nightmare_chased,distance=..80] ~ ~ ~ 0.9 0.45
execute as @e[tag=nightmare_stalker,limit=1] at @s run playsound minecraft:ambient.cave master @a[tag=nightmare_chased,distance=..80] ~ ~ ~ 0.7 0.3
execute as @e[tag=nightmare_stalker,limit=1] at @s run particle minecraft:ash ~ ~1 ~ 2 2 2 0.03 80 force
execute as @e[tag=nightmare_stalker,limit=1] at @s run effect give @a[tag=nightmare_chased,distance=..80] minecraft:darkness 5 0 true

execute if score #event_stage nm_timer matches 2 as @e[tag=nightmare_stalker,limit=1] at @s facing entity @p[tag=nightmare_chased,sort=nearest,limit=1] feet rotated ~ 0 run tp @s ^ ^ ^8
execute if score #event_stage nm_timer matches 3 as @e[tag=nightmare_stalker,limit=1] at @s run playsound minecraft:entity.enderman.scream master @a[tag=nightmare_chased,distance=..80] ~ ~ ~ 0.8 0.5
execute if score #event_stage nm_timer matches 4 if entity @e[tag=nightmare_stalker] run kick @p[tag=nightmare_chased,sort=nearest,limit=1] IT SAW YOU. DO NOT COME BACK ALONE.
