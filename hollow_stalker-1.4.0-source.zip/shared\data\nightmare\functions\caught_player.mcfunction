tag @p[tag=nightmare_chased,distance=..1.7,sort=nearest,limit=1] add nightmare_caught
gamemode survival @a[tag=nightmare_caught,gamemode=adventure]
tag @a[tag=nightmare_caught] remove nightmare_chased
kill @a[tag=nightmare_caught]
