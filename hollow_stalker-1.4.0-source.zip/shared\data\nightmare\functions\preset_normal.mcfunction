scoreboard players set #difficulty nm_timer 2
scoreboard players set #grace_length nm_timer 400
scoreboard players set #fake_gap nm_timer 7200
tellraw @a {"text":"Hollow preset set to NORMAL.","color":"gray"}
