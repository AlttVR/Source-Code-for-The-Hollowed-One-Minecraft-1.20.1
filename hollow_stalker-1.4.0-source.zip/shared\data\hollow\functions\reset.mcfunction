function nightmare:remove_stalker
function nightmare:load
