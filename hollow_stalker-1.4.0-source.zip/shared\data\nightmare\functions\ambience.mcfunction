scoreboard players set #ambient nm_timer 0
execute at @a[tag=nightmare_chased] run playsound minecraft:ambient.cave master @s ~ ~ ~ 0.45 0.45
execute at @a[tag=nightmare_chased] run playsound minecraft:entity.warden.ambient master @s ~ ~ ~ 0.25 0.6
execute at @a[tag=nightmare_chased] run playsound minecraft:block.portal.ambient master @s ~ ~ ~ 0.18 0.35
execute at @a[tag=nightmare_chased] run effect give @s minecraft:darkness 2 0 true
