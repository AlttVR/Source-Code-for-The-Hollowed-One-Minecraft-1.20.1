execute if entity @p[tag=nightmare_chased,distance=..120] run effect give @p[tag=nightmare_chased,distance=..120,sort=nearest,limit=1] minecraft:darkness 2 0 true
execute if entity @p[tag=nightmare_chased,distance=..90] run attribute @s minecraft:generic.movement_speed base set 0.78
execute if entity @p[tag=nightmare_chased,distance=..90] facing entity @p[tag=nightmare_chased,sort=nearest,limit=1] feet rotated ~ 0 run tp @s ^ ^ ^0.20
execute if entity @p[tag=nightmare_chased,distance=..50] run playsound minecraft:entity.enderman.stare master @p[tag=nightmare_chased,sort=nearest,limit=1] ~ ~ ~ 0.45 0.35
