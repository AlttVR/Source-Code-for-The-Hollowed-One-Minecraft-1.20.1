execute at @s run spreadplayers ~ ~ 275 300 false @e[tag=nightmare_new,limit=1,sort=nearest]
execute as @e[tag=nightmare_new,sort=nearest,limit=1] at @s run summon minecraft:armor_stand ~ ~ ~ {Tags:["nightmare_anchor"],Invisible:1b,Marker:1b,NoGravity:1b,Invulnerable:1b,Silent:1b}
execute as @e[tag=nightmare_anchor,sort=nearest,limit=1] at @s run forceload add ~ ~
effect give @e[tag=nightmare_new,sort=nearest,limit=1] minecraft:resistance infinite 2 true
effect give @e[tag=nightmare_new,sort=nearest,limit=1] minecraft:fire_resistance infinite 1 true
effect give @e[tag=nightmare_new,sort=nearest,limit=1] minecraft:speed infinite 0 true
effect clear @e[tag=nightmare_new,sort=nearest,limit=1] minecraft:invisibility
scoreboard players set @e[tag=nightmare_new,sort=nearest,limit=1] nm_cooldown 0
scoreboard players operation @e[tag=nightmare_new,sort=nearest,limit=1] nm_mood = #grace_length nm_timer
tag @e[tag=nightmare_new,sort=nearest,limit=1] remove nightmare_new
playsound minecraft:entity.warden.emerge master @a ~ ~ ~ 1 0.55
playsound minecraft:ambient.cave master @a ~ ~ ~ 0.8 0.35
title @a actionbar {"text":"IT SAW YOU","color":"white","bold":false}
