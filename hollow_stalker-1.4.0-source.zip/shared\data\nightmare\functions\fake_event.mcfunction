scoreboard players set #fake nm_timer 0
execute as @a[gamemode=survival] at @s unless entity @e[tag=nightmare_stalker,distance=..380] run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.35
execute as @a[gamemode=survival] at @s unless entity @e[tag=nightmare_stalker,distance=..380] run playsound minecraft:block.note_block.basedrum master @s ~ ~ ~ 0.35 0.25
execute as @a[gamemode=survival] at @s unless entity @e[tag=nightmare_stalker,distance=..380] run playsound minecraft:ambient.cave master @s ~ ~ ~ 0.35 0.3
execute as @a[gamemode=survival] at @s unless entity @e[tag=nightmare_stalker,distance=..380] run title @s actionbar {"text":"...","color":"white","bold":false}
