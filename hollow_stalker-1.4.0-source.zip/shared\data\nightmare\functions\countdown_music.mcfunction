scoreboard players set #music nm_timer 0
execute as @e[tag=nightmare_stalker] at @s if entity @p[tag=nightmare_chased,distance=276..320] run playsound minecraft:block.note_block.bass master @p[tag=nightmare_chased,sort=nearest,limit=1] ~ ~ ~ 0.55 0.55
execute as @e[tag=nightmare_stalker] at @s if entity @p[tag=nightmare_chased,distance=151..275] run playsound minecraft:block.note_block.bass master @p[tag=nightmare_chased,sort=nearest,limit=1] ~ ~ ~ 0.75 0.45
execute as @e[tag=nightmare_stalker] at @s if entity @p[tag=nightmare_chased,distance=51..150] run playsound minecraft:block.note_block.bass master @p[tag=nightmare_chased,sort=nearest,limit=1] ~ ~ ~ 0.95 0.35
execute as @e[tag=nightmare_stalker] at @s if entity @p[tag=nightmare_chased,distance=16..50] run playsound minecraft:block.note_block.basedrum master @p[tag=nightmare_chased,sort=nearest,limit=1] ~ ~ ~ 1.15 0.25
execute as @e[tag=nightmare_stalker] at @s if entity @p[tag=nightmare_chased,distance=..15] run playsound minecraft:entity.warden.heartbeat master @p[tag=nightmare_chased,sort=nearest,limit=1] ~ ~ ~ 1.4 0.35
