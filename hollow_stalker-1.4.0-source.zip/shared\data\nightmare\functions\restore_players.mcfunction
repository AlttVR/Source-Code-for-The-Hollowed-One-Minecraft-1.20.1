gamemode survival @a[tag=nightmare_chased,gamemode=adventure]
tag @a[tag=nightmare_chased] remove nightmare_chased
tellraw @a {"text":"Hollow released all chased players.","color":"gray"}
