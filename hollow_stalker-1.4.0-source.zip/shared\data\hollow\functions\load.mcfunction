function nightmare:load
