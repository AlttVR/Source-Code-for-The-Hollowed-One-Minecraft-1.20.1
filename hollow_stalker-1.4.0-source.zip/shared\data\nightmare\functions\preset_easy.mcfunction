scoreboard players set #difficulty nm_timer 1
scoreboard players set #grace_length nm_timer 600
scoreboard players set #fake_gap nm_timer 9600
tellraw @a {"text":"Hollow preset set to EASY.","color":"gray"}
