scoreboard objectives add nm_timer dummy
scoreboard objectives add nm_cooldown dummy
scoreboard objectives add nm_mood dummy
scoreboard players set #ambient nm_timer 0
scoreboard players set #break nm_timer 0
scoreboard players set #pulse nm_timer 0
scoreboard players set #event nm_timer 0
scoreboard players set #event_gap nm_timer 2400
scoreboard players set #event_stage nm_timer 0
scoreboard players set #music nm_timer 0
scoreboard players set #fake nm_timer 0
scoreboard players set #fake_gap nm_timer 7200
scoreboard players set #difficulty nm_timer 2
scoreboard players set #grace_length nm_timer 400
tellraw @a [{"text":"Hollow Stalker loaded. Run ","color":"dark_gray"},{"text":"/function hollow:summon","color":"white"},{"text":" when you want it to find you.","color":"dark_gray"}]
