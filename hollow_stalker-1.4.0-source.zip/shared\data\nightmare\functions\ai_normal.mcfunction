attribute @s minecraft:generic.movement_speed base set 0.30
execute if entity @p[tag=nightmare_chased,distance=..275] run attribute @s minecraft:generic.movement_speed base set 0.68
execute if entity @p[tag=nightmare_chased,distance=..15] run attribute @s minecraft:generic.movement_speed base set 0.95
execute if entity @p[tag=nightmare_chased,distance=276..320] facing entity @p[tag=nightmare_chased,sort=nearest,limit=1] feet rotated ~ 0 run tp @s ^ ^ ^0.18
execute if entity @p[tag=nightmare_chased,distance=16..275] facing entity @p[tag=nightmare_chased,sort=nearest,limit=1] feet rotated ~ 0 run tp @s ^ ^ ^0.45
execute if entity @p[tag=nightmare_chased,distance=..15] facing entity @p[tag=nightmare_chased,sort=nearest,limit=1] feet rotated ~ 0 run tp @s ^ ^ ^0.65
execute if entity @p[tag=nightmare_chased,distance=..15] if score @s nm_cooldown matches ..0 run function nightmare:close_stage
