execute as @e[tag=nightmare_anchor] at @s run forceload remove ~ ~
kill @e[tag=nightmare_stalker]
kill @e[tag=nightmare_anchor]
stopsound @a master minecraft:entity.warden.heartbeat
gamemode survival @a[tag=nightmare_chased,gamemode=adventure]
tag @a[tag=nightmare_chased] remove nightmare_chased
tellraw @a {"text":"The Stalker has been removed.","color":"gray"}
