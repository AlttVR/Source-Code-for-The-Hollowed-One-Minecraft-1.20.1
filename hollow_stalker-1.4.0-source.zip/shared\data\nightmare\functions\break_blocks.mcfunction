execute positioned ^ ^ ^1 run fill ~-1 ~ ~-1 ~1 ~2 ~1 minecraft:air destroy
execute positioned ^ ^1 ^2 run fill ~-1 ~-1 ~-1 ~1 ~1 ~1 minecraft:air destroy
execute positioned ^ ^-1 ^1 run fill ~-1 ~ ~-1 ~1 ~1 ~1 minecraft:air destroy
playsound minecraft:block.deepslate.break master @a[distance=..24] ~ ~ ~ 0.5 0.55
