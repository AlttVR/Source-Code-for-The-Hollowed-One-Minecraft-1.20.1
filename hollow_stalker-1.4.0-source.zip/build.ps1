$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$outDir = Join-Path $root "dist"
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

function New-JarFromParts {
  param(
    [string]$Loader,
    [string]$OutputName
  )

  $output = Join-Path $outDir $OutputName
  $fs = [System.IO.File]::Open($output, [System.IO.FileMode]::Create)
  try {
    $zip = New-Object System.IO.Compression.ZipArchive($fs, [System.IO.Compression.ZipArchiveMode]::Create)
    try {
      foreach ($sourceDir in @((Join-Path $root "shared"), (Join-Path $root "loaders\$Loader"))) {
        Get-ChildItem -Path $sourceDir -Recurse -File | ForEach-Object {
          $relative = $_.FullName.Substring($sourceDir.Length + 1).Replace('\', '/')
          $entry = $zip.CreateEntry($relative, [System.IO.Compression.CompressionLevel]::Optimal)
          $entryStream = $entry.Open()
          try {
            $fileStream = [System.IO.File]::OpenRead($_.FullName)
            try {
              $fileStream.CopyTo($entryStream)
            } finally {
              $fileStream.Dispose()
            }
          } finally {
            $entryStream.Dispose()
          }
        }
      }
    } finally {
      $zip.Dispose()
    }
  } finally {
    $fs.Dispose()
  }
}

New-JarFromParts "forge" "hollow_stalker-1.4.0-forge-1.20.1.jar"
New-JarFromParts "neoforge" "hollow_stalker-1.4.0-neoforge-1.20.1.jar"
New-JarFromParts "fabric" "hollow_stalker-1.4.0-fabric-1.20.1.jar"
New-JarFromParts "quilt" "hollow_stalker-1.4.0-quilt-1.20.1.jar"

Get-ChildItem $outDir -Filter *.jar | Select-Object Name, Length
