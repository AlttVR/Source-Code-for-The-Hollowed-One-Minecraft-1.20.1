scoreboard players set #pulse nm_timer 0
execute as @e[tag=nightmare_stalker] at @s if entity @p[tag=nightmare_chased,distance=..48] run particle minecraft:ash ~ ~1 ~ 0.8 1.4 0.8 0.02 30 force
execute as @e[tag=nightmare_stalker] at @s if entity @p[tag=nightmare_chased,distance=..48] run playsound minecraft:entity.enderman.stare master @p[tag=nightmare_chased,distance=..48,sort=nearest,limit=1] ~ ~ ~ 0.7 0.55
