scoreboard players set #difficulty nm_timer 3
scoreboard players set #grace_length nm_timer 240
scoreboard players set #fake_gap nm_timer 4800
tellraw @a {"text":"Hollow preset set to NIGHTMARE.","color":"dark_red"}
