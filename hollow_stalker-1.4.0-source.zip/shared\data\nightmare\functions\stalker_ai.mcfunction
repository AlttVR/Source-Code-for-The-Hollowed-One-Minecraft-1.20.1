effect give @s minecraft:night_vision 2 0 true
effect clear @s minecraft:invisibility
scoreboard players remove @s nm_cooldown 1
scoreboard players remove @s nm_mood 1
execute as @e[tag=nightmare_anchor,limit=1,sort=nearest] at @s run forceload remove ~ ~
execute at @s run tp @e[tag=nightmare_anchor,limit=1,sort=nearest] ~ ~ ~
execute as @e[tag=nightmare_anchor,limit=1,sort=nearest] at @s run forceload add ~ ~

execute unless entity @p[tag=nightmare_chased,distance=..340] run tp @s ~ ~ ~

execute if score @s nm_mood matches 1.. run function nightmare:grace_chase
execute if score @s nm_mood matches ..0 if score #difficulty nm_timer matches 1 run function nightmare:ai_easy
execute if score @s nm_mood matches ..0 if score #difficulty nm_timer matches 2 run function nightmare:ai_normal
execute if score @s nm_mood matches ..0 if score #difficulty nm_timer matches 3.. run function nightmare:ai_nightmare
execute if score @s nm_mood matches ..0 if entity @s[tag=hollow_unknown] run function nightmare:ai_unknown
execute if score @s nm_mood matches ..0 if entity @s[tag=hollow_mimic] run function nightmare:ai_mimic
execute if score @s nm_mood matches ..0 if entity @s[tag=hollow_longmouth] run function nightmare:ai_longmouth

execute if score #break nm_timer matches 0 at @s run function nightmare:break_blocks

execute at @s if entity @p[tag=nightmare_chased,distance=..7] run playsound minecraft:entity.warden.heartbeat master @p[tag=nightmare_chased,distance=..12] ~ ~ ~ 1.2 0.45
execute at @s if entity @p[tag=nightmare_chased,distance=..3] run effect give @p[tag=nightmare_chased,distance=..3,sort=nearest,limit=1] minecraft:darkness 4 0 true
execute at @s if entity @p[tag=nightmare_chased,distance=..2] run playsound minecraft:entity.enderman.scream master @a ~ ~ ~ 1 0.5
execute at @s if entity @p[tag=nightmare_chased,distance=..1.7] run function nightmare:caught_player
