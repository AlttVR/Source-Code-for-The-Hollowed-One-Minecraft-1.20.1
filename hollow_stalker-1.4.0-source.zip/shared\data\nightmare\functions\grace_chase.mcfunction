attribute @s minecraft:generic.movement_speed base set 0.18
execute if score @s nm_mood matches 380..400 run title @a[tag=nightmare_chased] actionbar {"text":"IT SAW YOU","color":"white","bold":false}
execute if score @s nm_mood matches 20 at @s run playsound minecraft:block.note_block.bass master @p[tag=nightmare_chased,sort=nearest,limit=1] ~ ~ ~ 0.8 0.25
execute if score @s nm_mood matches 60 at @s run playsound minecraft:block.note_block.bass master @p[tag=nightmare_chased,sort=nearest,limit=1] ~ ~ ~ 0.8 0.25
execute if score @s nm_mood matches 100 at @s run playsound minecraft:block.note_block.bass master @p[tag=nightmare_chased,sort=nearest,limit=1] ~ ~ ~ 0.8 0.25
execute if score @s nm_mood matches 140 at @s run playsound minecraft:block.note_block.bass master @p[tag=nightmare_chased,sort=nearest,limit=1] ~ ~ ~ 0.8 0.25
execute if score @s nm_mood matches 180 at @s run playsound minecraft:block.note_block.bass master @p[tag=nightmare_chased,sort=nearest,limit=1] ~ ~ ~ 0.8 0.25
execute if score @s nm_mood matches 220 at @s run playsound minecraft:block.note_block.bass master @p[tag=nightmare_chased,sort=nearest,limit=1] ~ ~ ~ 0.8 0.25
execute if score @s nm_mood matches 260 at @s run playsound minecraft:block.note_block.bass master @p[tag=nightmare_chased,sort=nearest,limit=1] ~ ~ ~ 0.8 0.25
execute if score @s nm_mood matches 300 at @s run playsound minecraft:block.note_block.bass master @p[tag=nightmare_chased,sort=nearest,limit=1] ~ ~ ~ 0.8 0.25
execute if score @s nm_mood matches 340 at @s run playsound minecraft:block.note_block.bass master @p[tag=nightmare_chased,sort=nearest,limit=1] ~ ~ ~ 0.8 0.25
execute if score @s nm_mood matches 380 at @s run playsound minecraft:block.note_block.bass master @p[tag=nightmare_chased,sort=nearest,limit=1] ~ ~ ~ 0.8 0.25
execute facing entity @p[tag=nightmare_chased,sort=nearest,limit=1] feet rotated ~ 0 run tp @s ^ ^ ^0.08
