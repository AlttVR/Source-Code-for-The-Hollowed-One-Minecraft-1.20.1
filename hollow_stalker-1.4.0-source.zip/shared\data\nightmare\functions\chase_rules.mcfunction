execute if entity @e[tag=nightmare_stalker] as @a[gamemode=survival] at @s if entity @e[tag=nightmare_stalker,distance=..340] run tag @s add nightmare_chased
gamemode adventure @a[tag=nightmare_chased,gamemode=survival]
execute as @a[tag=nightmare_chased,gamemode=adventure] at @s unless entity @e[tag=nightmare_stalker,distance=..380] run gamemode survival @s
execute as @a[tag=nightmare_chased] at @s unless entity @e[tag=nightmare_stalker,distance=..380] run tag @s remove nightmare_chased
execute unless entity @e[tag=nightmare_stalker] run gamemode survival @a[tag=nightmare_chased,gamemode=adventure]
execute unless entity @e[tag=nightmare_stalker] as @e[tag=nightmare_anchor] at @s run forceload remove ~ ~
execute unless entity @e[tag=nightmare_stalker] run kill @e[tag=nightmare_anchor]
execute unless entity @e[tag=nightmare_stalker] run tag @a[tag=nightmare_chased] remove nightmare_chased
