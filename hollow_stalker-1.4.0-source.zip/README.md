# Hollow Stalker Source

Hollow Stalker is a Minecraft 1.20.1 horror mod by Render4.

This is the source package for the data-driven release. Gameplay is implemented with Minecraft functions and shared assets, while each supported loader has its own metadata wrapper.

## Supported Loaders

- Forge 1.20.1
- NeoForge 1.20.1
- Fabric 1.20.1
- Quilt 1.20.1

## Layout

- `shared/` - common `data/`, `assets/`, `pack.mcmeta`, and mod icon.
- `loaders/forge/` - Forge metadata.
- `loaders/neoforge/` - NeoForge metadata.
- `loaders/fabric/` - Fabric metadata.
- `loaders/quilt/` - Quilt metadata.
- `build.ps1` - local script to rebuild release jars from this source folder.

## Commands

- `/function hollow:summon`
- `/function hollow:summon_eyeless`
- `/function hollow:summon_unknown`
- `/function hollow:summon_mimic`
- `/function hollow:summon_longmouth`
- `/function hollow:summon_all`
- `/function hollow:easy`
- `/function hollow:normal`
- `/function hollow:nightmare`
- `/function hollow:restore`
- `/function hollow:remove`
- `/function hollow:help`

## Notes

This release is data-driven and uses vanilla zombie-family entities with custom textures and function-based behavior. A future compiled version can add true custom entities and a root `/hollow` command.
