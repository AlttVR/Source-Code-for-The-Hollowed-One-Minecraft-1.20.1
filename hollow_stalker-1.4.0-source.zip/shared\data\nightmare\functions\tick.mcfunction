scoreboard players add #ambient nm_timer 1
scoreboard players add #break nm_timer 1
scoreboard players add #pulse nm_timer 1
scoreboard players add #event nm_timer 1
scoreboard players add #music nm_timer 1
scoreboard players add #fake nm_timer 1

function nightmare:chase_rules
execute as @e[tag=nightmare_stalker] at @s run function nightmare:stalker_ai

execute if score #ambient nm_timer matches 100.. run function nightmare:ambience
execute if score #break nm_timer matches 5.. run scoreboard players set #break nm_timer 0
execute if score #pulse nm_timer matches 35.. run function nightmare:pulse
execute if score #music nm_timer matches 20.. run function nightmare:countdown_music
execute if score #event nm_timer >= #event_gap nm_timer run function nightmare:event
execute if score #fake nm_timer >= #fake_gap nm_timer run function nightmare:fake_event
