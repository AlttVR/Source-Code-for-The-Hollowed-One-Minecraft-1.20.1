scoreboard players set @s nm_cooldown 120
execute as @p[tag=nightmare_chased,sort=nearest,limit=1] at @s positioned ^ ^ ^-4 run tp @e[tag=nightmare_stalker,sort=nearest,limit=1] ~ ~ ~
execute as @p[tag=nightmare_chased,sort=nearest,limit=1] at @s run title @s actionbar {"text":"IT SAW YOU","color":"white","bold":false}
execute as @p[tag=nightmare_chased,sort=nearest,limit=1] at @s run effect give @s minecraft:darkness 4 0 true
execute as @p[tag=nightmare_chased,sort=nearest,limit=1] at @s run playsound minecraft:entity.enderman.scream master @s ~ ~ ~ 1 0.45
execute as @p[tag=nightmare_chased,sort=nearest,limit=1] at @s run particle minecraft:ash ~ ~1 ~ 1.5 1.5 1.5 0.04 100 force
