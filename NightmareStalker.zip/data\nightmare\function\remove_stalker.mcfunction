kill @e[tag=nightmare_stalker]
stopsound @a master minecraft:entity.warden.heartbeat
tellraw @a {"text":"The Stalker has been removed.","color":"gray"}
