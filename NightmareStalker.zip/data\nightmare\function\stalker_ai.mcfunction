effect give @s minecraft:slow_falling 2 1 true
effect give @s minecraft:night_vision 2 0 true

execute unless entity @p[gamemode=survival,distance=..128] run tp @s ~ ~ ~

execute if entity @p[gamemode=survival,distance=..96] facing entity @p[gamemode=survival,sort=nearest,limit=1] eyes run tp @s ^ ^ ^0.42
execute if entity @p[gamemode=survival,distance=24..96] facing entity @p[gamemode=survival,sort=nearest,limit=1] eyes run tp @s ^ ^0.08 ^0.28
execute if entity @p[gamemode=survival,distance=..18] facing entity @p[gamemode=survival,sort=nearest,limit=1] eyes run tp @s ^ ^ ^0.62

execute if score #break nm_timer matches 0 at @s run function nightmare:break_blocks

execute at @s if entity @p[gamemode=survival,distance=..7] run playsound minecraft:entity.warden.heartbeat master @p[gamemode=survival,distance=..12] ~ ~ ~ 1.2 0.45
execute at @s if entity @p[gamemode=survival,distance=..3] run effect give @p[gamemode=survival,distance=..3,sort=nearest,limit=1] minecraft:darkness 4 0 true
execute at @s if entity @p[gamemode=survival,distance=..2] run playsound minecraft:entity.enderman.scream master @a ~ ~ ~ 1 0.5
execute at @s if entity @p[gamemode=survival,distance=..1.7] run kill @p[gamemode=survival,distance=..1.7,sort=nearest,limit=1]
