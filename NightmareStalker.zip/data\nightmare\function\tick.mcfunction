scoreboard players add #ambient nm_timer 1
scoreboard players add #break nm_timer 1
scoreboard players add #pulse nm_timer 1

execute as @e[tag=nightmare_stalker] at @s run function nightmare:stalker_ai

execute if score #ambient nm_timer matches 100.. run function nightmare:ambience
execute if score #break nm_timer matches 5.. run scoreboard players set #break nm_timer 0
execute if score #pulse nm_timer matches 35.. run function nightmare:pulse
