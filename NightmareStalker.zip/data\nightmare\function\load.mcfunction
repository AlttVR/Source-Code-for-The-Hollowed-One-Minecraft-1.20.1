scoreboard objectives add nm_timer dummy
scoreboard objectives add nm_cooldown dummy
scoreboard objectives add nm_mood dummy
scoreboard players set #ambient nm_timer 0
scoreboard players set #break nm_timer 0
scoreboard players set #pulse nm_timer 0
tellraw @a [{"text":"Nightmare Stalker loaded. Run ","color":"dark_gray"},{"text":"/function nightmare:summon_stalker","color":"red"},{"text":" when you want it to find you.","color":"dark_gray"}]
