summon minecraft:warden ~ ~1 ~ {Tags:["nightmare_stalker"],CustomName:'{"text":"The Stalker","color":"dark_red","bold":true}',CustomNameVisible:1b,PersistenceRequired:1b,Health:500f,NoGravity:1b,Silent:0b}
effect give @e[tag=nightmare_stalker,sort=nearest,limit=1] minecraft:resistance infinite 2 true
effect give @e[tag=nightmare_stalker,sort=nearest,limit=1] minecraft:fire_resistance infinite 1 true
effect give @e[tag=nightmare_stalker,sort=nearest,limit=1] minecraft:speed infinite 1 true
playsound minecraft:entity.warden.emerge master @a ~ ~ ~ 1 0.55
playsound minecraft:ambient.cave master @a ~ ~ ~ 0.8 0.35
title @a title {"text":"IT HEARD YOU","color":"dark_red","bold":true}
